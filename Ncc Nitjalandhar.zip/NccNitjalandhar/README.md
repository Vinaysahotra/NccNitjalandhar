# NccNitjalandhar
![Screenshot_2020-09-03-09-26-56-179_com example nccnitjalandhar](https://user-images.githubusercontent.com/70520048/92079460-8dc0ce80-eddd-11ea-8f30-726ea7f0b8c1.jpg)
![Screenshot_2020-09-03-09-27-15-307_com example nccnitjalandhar](https://user-images.githubusercontent.com/70520048/92079873-4424b380-edde-11ea-89cc-0702561200b2.jpg)
nit jalandhar ncc app
this is an app regarding basic communication to increase communication among ncc cadets at nit jalandhar.
It consists of basic grid views,intents and xml code.apk file is connected.
It is not ready yet but soon i will complete it.. 
